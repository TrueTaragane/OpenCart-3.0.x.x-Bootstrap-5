/**
 * Bootstrap Icons SVG Loader для OpenCart
 * Загружает SVG иконки из папки icons/
 */
(function() {
    'use strict';
    
    // Базовый путь к иконкам
    var ICONS_PATH = 'catalog/view/javascript/bootstrap/icons/';
    
    // Кэш загруженных иконок
    var iconsCache = {};
    
    // Карта наиболее используемых иконок в OpenCart
    var commonIcons = {
        'cart': 'cart.svg',
        'cart-plus': 'cart-plus.svg',
        'cart-check': 'cart-check.svg',
        'cart-dash': 'cart-dash.svg',
        'cart-x': 'cart-x.svg',
        'heart': 'heart.svg',
        'heart-fill': 'heart-fill.svg',
        'search': 'search.svg',
        'person': 'person.svg',
        'person-fill': 'person-fill.svg',
        'house': 'house.svg',
        'house-fill': 'house-fill.svg',
        'envelope': 'envelope.svg',
        'envelope-fill': 'envelope-fill.svg',
        'telephone': 'telephone.svg',
        'telephone-fill': 'telephone-fill.svg',
        'geo-alt': 'geo-alt.svg',
        'geo-alt-fill': 'geo-alt-fill.svg',
        'star': 'star.svg',
        'star-fill': 'star-fill.svg',
        'star-half': 'star-half.svg',
        'eye': 'eye.svg',
        'eye-fill': 'eye-fill.svg',
        'eye-slash': 'eye-slash.svg',
        'x': 'x.svg',
        'x-lg': 'x-lg.svg',
        'plus': 'plus.svg',
        'plus-lg': 'plus-lg.svg',
        'dash': 'dash.svg',
        'dash-lg': 'dash-lg.svg',
        'check': 'check.svg',
        'check-lg': 'check-lg.svg',
        'check-circle': 'check-circle.svg',
        'check-circle-fill': 'check-circle-fill.svg',
        'exclamation-triangle': 'exclamation-triangle.svg',
        'exclamation-triangle-fill': 'exclamation-triangle-fill.svg',
        'info-circle': 'info-circle.svg',
        'info-circle-fill': 'info-circle-fill.svg',
        'arrow-left': 'arrow-left.svg',
        'arrow-right': 'arrow-right.svg',
        'arrow-up': 'arrow-up.svg',
        'arrow-down': 'arrow-down.svg',
        'chevron-left': 'chevron-left.svg',
        'chevron-right': 'chevron-right.svg',
        'chevron-up': 'chevron-up.svg',
        'chevron-down': 'chevron-down.svg',
        'list': 'list.svg',
        'grid': 'grid.svg',
        'grid-3x3': 'grid-3x3.svg',
        'filter': 'filter.svg',
        'sort-down': 'sort-down.svg',
        'sort-up': 'sort-up.svg'
    };
    
    /**
     * Загрузить SVG иконку
     */
    function loadIcon(iconName, callback) {
        if (iconsCache[iconName]) {
            callback(iconsCache[iconName]);
            return;
        }
        
        var filename = commonIcons[iconName] || (iconName + '.svg');
        var url = ICONS_PATH + filename;
        
        fetch(url)
            .then(function(response) {
                if (!response.ok) {
                    throw new Error('Icon not found: ' + iconName);
                }
                return response.text();
            })
            .then(function(svgContent) {
                iconsCache[iconName] = svgContent;
                callback(svgContent);
            })
            .catch(function(error) {
                console.warn('Failed to load icon:', iconName, error);
                callback(null);
            });
    }
    
    /**
     * Заменить все иконки на странице
     */
    function replaceIcons() {
        var iconElements = document.querySelectorAll('[class*="bi-"]');
        
        iconElements.forEach(function(element) {
            var classes = element.className.split(' ');
            var iconClass = classes.find(function(cls) {
                return cls.startsWith('bi-') && cls !== 'bi';
            });
            
            if (iconClass) {
                var iconName = iconClass.replace('bi-', '');
                
                loadIcon(iconName, function(svgContent) {
                    if (svgContent) {
                        // Создаем временный элемент для парсинга SVG
                        var tempDiv = document.createElement('div');
                        tempDiv.innerHTML = svgContent;
                        var svgElement = tempDiv.querySelector('svg');
                        
                        if (svgElement) {
                            // Копируем классы с оригинального элемента
                            svgElement.className.baseVal = element.className;
                            
                            // Заменяем элемент
                            element.parentNode.replaceChild(svgElement, element);
                        }
                    }
                });
            }
        });
    }
    
    /**
     * Инициализация
     */
    function init() {
        // Заменяем иконки при загрузке страницы
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', replaceIcons);
        } else {
            replaceIcons();
        }
        
        // Заменяем иконки после AJAX запросов
        if (typeof $ !== 'undefined') {
            $(document).ajaxComplete(function() {
                setTimeout(replaceIcons, 100);
            });
        }
        
        // Наблюдаем за изменениями DOM
        if (typeof MutationObserver !== 'undefined') {
            var observer = new MutationObserver(function(mutations) {
                var shouldReplace = false;
                mutations.forEach(function(mutation) {
                    if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                        shouldReplace = true;
                    }
                });
                
                if (shouldReplace) {
                    setTimeout(replaceIcons, 100);
                }
            });
            
            observer.observe(document.body, {
                childList: true,
                subtree: true
            });
        }
    }
    
    // Публичный API
    window.BootstrapIconsLoader = {
        loadIcon: loadIcon,
        replaceIcons: replaceIcons,
        init: init,
        cache: iconsCache
    };
    
    // Автоматическая инициализация
    init();
    
})();