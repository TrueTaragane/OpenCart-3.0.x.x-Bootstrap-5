/**
 * OpenCart Common JavaScript Functions
 * Bootstrap 5 Compatible Version
 * 
 * Updated for Bootstrap 5 and modern JavaScript practices
 */

// Получение URL параметров
function getURLVar(key) {
    var value = [];
    var query = String(document.location).split('?');

    if (query[1]) {
        var part = query[1].split('&');

        for (i = 0; i < part.length; i++) {
            var data = part[i].split('=');

            if (data[0] && data[1]) {
                value[data[0]] = data[1];
            }
        }

        if (value[key]) {
            return value[key];
        } else {
            return '';
        }
    }
}

$(document).ready(function() {
    // Инициализация Bootstrap 5 компонентов
    initBootstrap5Components();
    
    // Подсветка ошибок валидации - Bootstrap 5 версия
    $('.text-danger').each(function() {
        var element = $(this).closest('.mb-3').find('.form-control, .form-select');
        if (element.length) {
            element.addClass('is-invalid');
        }
    });

    // Подсветка успешных сообщений - Bootstrap 5 версия
    $('.text-success').each(function() {
        var element = $(this).closest('.mb-3').find('.form-control, .form-select');
        if (element.length) {
            element.addClass('is-valid');
        }
    });

    // Валюта
    $('#form-currency .currency-select').on('click', function(e) {
        e.preventDefault();
        $('#form-currency input[name=\'code\']').val($(this).attr('name'));
        $('#form-currency').submit();
    });

    // Язык
    $('#form-language .language-select').on('click', function(e) {
        e.preventDefault();
        $('#form-language input[name=\'code\']').val($(this).attr('name'));
        $('#form-language').submit();
    });

    // Поиск
    $('#search input[name=\'search\']').parent().find('button').on('click', function() {
        var url = $('base').attr('href') + 'index.php?route=product/search';
        var value = $('header #search input[name=\'search\']').val();

        if (value) {
            url += '&search=' + encodeURIComponent(value);
        }

        location = url;
    });

    $('#search input[name=\'search\']').on('keydown', function(e) {
        if (e.keyCode == 13) {
            $('header #search input[name=\'search\']').parent().find('button').trigger('click');
        }
    });

    // Корзина
    $('#cart > button').on('click', function() {
        $('#cart').load('index.php?route=common/cart/info ul li');
    });

    $('#cart').load('index.php?route=common/cart/info ul li');

    // Wishlist
    $(document).on('click', '.btn-wishlist', function(e) {
        e.preventDefault();
        
        var button = $(this);
        var product_id = button.data('product-id') || button.closest('[data-product-id]').data('product-id');
        
        if (!product_id) {
            console.error('Product ID not found');
            return;
        }
        
        $.ajax({
            url: 'index.php?route=account/wishlist/add',
            type: 'post',
            data: 'product_id=' + product_id,
            dataType: 'json',
            success: function(json) {
                if (json['redirect']) {
                    location = json['redirect'];
                }

                if (json['success']) {
                    showAlert(json['success'], 'success');
                    
                    // Обновляем иконку
                    button.find('i').removeClass('bi-heart').addClass('bi-heart-fill');
                    button.addClass('text-danger');
                }

                $('#wishlist-total span').html(json['total']);
                $('#wishlist-total').attr('title', json['total']);
            },
            error: function(xhr, ajaxOptions, thrownError) {
                console.error(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
            }
        });
    });

    // Compare
    $(document).on('click', '.btn-compare', function(e) {
        e.preventDefault();
        
        var button = $(this);
        var product_id = button.data('product-id') || button.closest('[data-product-id]').data('product-id');
        
        if (!product_id) {
            console.error('Product ID not found');
            return;
        }
        
        $.ajax({
            url: 'index.php?route=product/compare/add',
            type: 'post',
            data: 'product_id=' + product_id,
            dataType: 'json',
            success: function(json) {
                if (json['success']) {
                    showAlert(json['success'], 'success');
                    
                    // Обновляем иконку
                    button.find('i').addClass('text-primary');
                }

                $('#compare-total').html(json['total']);
            },
            error: function(xhr, ajaxOptions, thrownError) {
                console.error(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
            }
        });
    });

    // Добавление в корзину
    $(document).on('click', '.btn-cart', function(e) {
        e.preventDefault();
        
        var button = $(this);
        var product_id = button.data('product-id') || button.closest('[data-product-id]').data('product-id');
        var quantity = button.data('quantity') || 1;
        
        if (!product_id) {
            console.error('Product ID not found');
            return;
        }
        
        // Показываем спиннер
        var originalHtml = button.html();
        button.html('<i class="bi bi-arrow-clockwise spin"></i>').prop('disabled', true);
        
        $.ajax({
            url: 'index.php?route=checkout/cart/add',
            type: 'post',
            data: 'product_id=' + product_id + '&quantity=' + quantity,
            dataType: 'json',
            success: function(json) {
                if (json['redirect']) {
                    location = json['redirect'];
                }

                if (json['success']) {
                    showAlert(json['success'], 'success');
                    
                    // Обновляем корзину
                    $('#cart-total').html(json['total']);
                    $('#cart').load('index.php?route=common/cart/info ul li');
                }
                
                // Восстанавливаем кнопку
                button.html(originalHtml).prop('disabled', false);
            },
            error: function(xhr, ajaxOptions, thrownError) {
                console.error(thrownError + "\r\n" + xhr.statusText + "\r\n" + xhr.responseText);
                button.html(originalHtml).prop('disabled', false);
            }
        });
    });

    // Переключение вида товаров (список/сетка)
    $(document).on('click', '#list-view', function() {
        $('#content .product-layout > .clearfix').remove();
        $('#content .product-layout').attr('class', 'product-layout product-list col-12');
        $('#grid-view').removeClass('btn-primary').addClass('btn-outline-secondary');
        $('#list-view').removeClass('btn-outline-secondary').addClass('btn-primary');
        
        localStorage.setItem('display', 'list');
    });

    $(document).on('click', '#grid-view', function() {
        $('#content .product-layout > .clearfix').remove();
        $('#content .product-layout').attr('class', 'product-layout product-grid col-lg-4 col-md-4 col-sm-6 col-12');
        $('#list-view').removeClass('btn-primary').addClass('btn-outline-secondary');
        $('#grid-view').removeClass('btn-outline-secondary').addClass('btn-primary');
        
        localStorage.setItem('display', 'grid');
    });

    // Восстановление вида из localStorage
    if (localStorage.getItem('display') == 'list') {
        $('#list-view').trigger('click');
    } else {
        $('#grid-view').trigger('click');
    }
});

/**
 * Инициализация Bootstrap 5 компонентов
 */
function initBootstrap5Components() {
    // Инициализация tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Инициализация popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Автоматическое скрытие алертов
    $('.alert[data-bs-dismiss="alert"]').each(function() {
        var alert = this;
        setTimeout(function() {
            if ($(alert).is(':visible')) {
                $(alert).fadeOut();
            }
        }, 5000);
    });
}

/**
 * Показать уведомление (Bootstrap 5 Alert)
 */
function showAlert(message, type, timeout) {
    type = type || 'info';
    timeout = timeout || 5000;
    
    var alertClass = 'alert-' + type;
    var iconClass = getAlertIcon(type);
    
    var alertHtml = '<div class="alert ' + alertClass + ' alert-dismissible fade show" role="alert">' +
                   '<i class="bi ' + iconClass + '"></i> ' + message +
                   '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>' +
                   '</div>';
    
    // Добавляем в начало контента
    $('#content').prepend(alertHtml);
    
    // Автоматическое скрытие
    if (timeout > 0) {
        setTimeout(function() {
            $('.alert').first().fadeOut(function() {
                $(this).remove();
            });
        }, timeout);
    }
}

/**
 * Получить иконку для типа алерта
 */
function getAlertIcon(type) {
    var icons = {
        'success': 'bi-check-circle',
        'danger': 'bi-exclamation-triangle',
        'warning': 'bi-exclamation-triangle',
        'info': 'bi-info-circle',
        'primary': 'bi-info-circle',
        'secondary': 'bi-info-circle'
    };
    
    return icons[type] || 'bi-info-circle';
}

/**
 * Показать модальное окно
 */
function showModal(selector, options) {
    options = options || {};
    
    var modalElement = document.querySelector(selector);
    if (modalElement) {
        var modal = new bootstrap.Modal(modalElement, options);
        modal.show();
        return modal;
    }
    
    console.error('Modal element not found: ' + selector);
    return null;
}

/**
 * Скрыть модальное окно
 */
function hideModal(selector) {
    var modalElement = document.querySelector(selector);
    if (modalElement) {
        var modal = bootstrap.Modal.getInstance(modalElement);
        if (modal) {
            modal.hide();
        }
    }
}

/**
 * Проверка Bootstrap 5
 */
function checkBootstrap5() {
    if (typeof bootstrap !== 'undefined') {
        console.log('✅ Bootstrap 5 loaded successfully');
        console.log('Bootstrap version:', bootstrap.Tooltip.VERSION || 'Unknown');
        return true;
    } else {
        console.error('❌ Bootstrap 5 not found');
        return false;
    }
}

/**
 * Анимация спиннера
 */
$(document).ready(function() {
    $('<style>')
        .prop('type', 'text/css')
        .html(`
            .spin {
                animation: spin 1s linear infinite;
            }
            @keyframes spin {
                from { transform: rotate(0deg); }
                to { transform: rotate(360deg); }
            }
        `)
        .appendTo('head');
});

// Глобальные функции для обратной совместимости
window.showAlert = showAlert;
window.showModal = showModal;
window.hideModal = hideModal;
window.checkBootstrap5 = checkBootstrap5;